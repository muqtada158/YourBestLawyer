<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class UserDetail extends Model
{
    use HasFactory;

    protected $casts = [
        'user_id' => 'integer',
    ];

    // Accessor for date conversion
    public function getDobAttribute($value)
    {
        return Carbon::parse($value)->format('d-m-Y');
    }
    public function setDobAttribute($value)
    {
        $this->attributes['dob'] = Carbon::parse($value)->format('Y-m-d');
    }

}
