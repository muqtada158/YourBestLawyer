<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerContractController extends Controller
{
    public function contract()
    {
        return view('customer.contract');
    }
}
