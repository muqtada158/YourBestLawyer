<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerProfileController extends Controller
{
    public function profile()
    {
        return view('customer.my-profile');
    }
    public function profile_edit()
    {
        return view('customer.my-profile-edit');
    }
}
