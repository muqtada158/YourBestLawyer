<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class CustomerInitials extends Controller
{
    public function update_profile()
    {
        $userProfile = User::with('getUserDetails')->where('id',auth()->user()->id)->first();
        return view('customer.initials.update-profile',compact('userProfile'));
    }

    public function updateProfile(Request $request)
    {

            //Validated
            $this->validate($request, [
                'first_name' => 'required',
                'last_name' => 'required',
                'dob' => 'required|date',
                'address' => 'required',
                'phone' => 'required',
                'image' => 'nullable|image|max:5120',
                'current_password' => 'nullable',
                'new_password' => 'required_with:old_password',
                'password_confirmation' => 'required_with:old_password|same:new_password'
            ]);

        try {
            $user_detail = UserDetail::where('user_id',auth()->user()->id)->firstOrNew();
            $user_detail->user_id = auth()->user()->id;
            $user_detail->first_name = $request->first_name;
            $user_detail->last_name = $request->last_name;
            $user_detail->dob = $request->dob;
            $user_detail->address = $request->address;
            $user_detail->phone = $request->phone;
            if ($request->hasFile('image')) {
                    /** Upload new image */
                    $upload_location = '/storage/profile/';
                    $file = $request->image;
                    $name_gen = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;
                    /** Saving in DB */
                    $user_detail->image = $save_url;
            }
            $user_detail->save();

            $user = User::with('getUserDetails')->where('id',auth()->user()->id)->first();

            if($request->current_password)
            {
                if (Hash::check($request->current_password, $user->password)) {
                    $user->password = Hash::make($request->password);
                } else {
                    $notification = [
                        'message' => 'Your current password is invalid.',
                        'alert-type' => 'error'
                    ];
                    return back()->with($notification);
                }
                $user->save();
            }

            if($user->restricted_steps == null)
            {
                $user->restricted_steps = 9;
                $user->save();
            }

            $notification = [
                'message' => 'Profile updated successfully.',
                'alert-type' => 'success'
            ];
            return redirect()->route('customer_application_steps')->with($notification);

        } catch (\Throwable $th) {
            $notification = [
                'message' => 'Error :'.$th->getMessage(),
                'alert-type' => 'error'
            ];
            return back()->with($notification);
        }
    }

    public function application_steps()
    {
        return view('customer.initials.application-steps');
    }
    public function hired_attornies()
    {
        return view('customer.initials.initial-hired-attornies');
    }
    public function hired_attornies_details()
    {
        return view('customer.initials.initial-attornies-details');
    }
    public function contracts()
    {
        return view('customer.initials.initial-contract');
    }
    public function checkout()
    {
        return view('customer.initials.checkout');
    }
    public function schedule()
    {
        return view('customer.initials.schedule');
    }
    public function schedule_appointment()
    {
        return view('customer.initials.initial-schedule-appointment');
    }
}
