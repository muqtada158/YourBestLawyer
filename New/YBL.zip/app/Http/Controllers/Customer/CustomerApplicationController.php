<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerApplicationController extends Controller
{
    public function applications()
    {
        return view('customer.applications');
    }

    public function add_application()
    {
        return view('customer.applications-add');
    }

    public function application_initial_process()
    {
        return view('customer.application-initial-process');
    }
}
