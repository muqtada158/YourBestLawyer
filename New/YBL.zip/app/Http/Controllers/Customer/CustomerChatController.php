<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerChatController extends Controller
{
    public function messages()
    {
        return view('customer.messages');
    }
}
