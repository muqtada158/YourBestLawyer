<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerAttorniesController extends Controller
{
    public function attornies()
    {
        return view('customer.attornies');
    }
    public function attornies_details()
    {
        return view('customer.attornies-detail');
    }
}
