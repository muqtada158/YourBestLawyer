<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerPaymentTransactionController extends Controller
{
    public function payment_transactions()
    {
        return view('customer.payment-transactions');
    }
    public function payment_transactions_add()
    {
        return view('customer.payment-transactions-add');
    }
}
