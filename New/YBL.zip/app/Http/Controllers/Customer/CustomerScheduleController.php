<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerScheduleController extends Controller
{
    public function schedule()
    {
        return view('customer.schedule');
    }
    public function schedule_appointment()
    {
        return view('customer.schedule-appointment');
    }
}
