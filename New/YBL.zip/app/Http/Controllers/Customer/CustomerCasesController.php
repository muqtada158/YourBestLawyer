<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerCasesController extends Controller
{
    public function cases()
    {
        return view('customer.cases');
    }
    public function all_cases()
    {
        return view('customer.cases-all');
    }
    public function current_potential_cases()
    {
        return view('customer.cases-current-potential');
    }
    public function case_details()
    {
        return view('customer.case-details');
    }
}
