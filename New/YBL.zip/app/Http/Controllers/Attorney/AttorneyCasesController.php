<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyCasesController extends Controller
{
    public function cases()
    {
        return view('attorney.cases');
    }
    public function all_cases()
    {
        return view('attorney.cases-all');
    }
    public function ongoing_cases()
    {
        return view('attorney.cases-ongoing');
    }
    public function case_details()
    {
        return view('attorney.case-details');
    }
}
