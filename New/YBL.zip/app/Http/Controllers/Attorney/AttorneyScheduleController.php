<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyScheduleController extends Controller
{
    public function schedule()
    {
        return view('attorney.schedule');
    }
    public function schedule_appointment()
    {
        return view('attorney.schedule-appointment');
    }
}
