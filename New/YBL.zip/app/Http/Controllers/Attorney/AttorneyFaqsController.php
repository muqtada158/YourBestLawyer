<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyFaqsController extends Controller
{
    public function faqs()
    {
        return view('attorney.faqs');
    }
}
