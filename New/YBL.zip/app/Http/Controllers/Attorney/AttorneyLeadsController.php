<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyLeadsController extends Controller
{
    public function leads()
    {
        return view('attorney.leads');
    }
    public function leads_customer_details()
    {
        return view('attorney.leads-customer-details');
    }
}
