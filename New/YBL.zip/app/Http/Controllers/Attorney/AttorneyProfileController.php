<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyProfileController extends Controller
{
    public function profile()
    {
        return view('attorney.my-profile');
    }
    public function profile_edit()
    {
        return view('attorney.my-profile-edit');
    }
}
