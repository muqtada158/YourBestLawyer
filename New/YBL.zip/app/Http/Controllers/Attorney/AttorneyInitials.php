<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyInitials extends Controller
{
    public function update_profile()
    {
        return view('attorney.initials.update-profile');
    }
    public function initial_application_form()
    {
        return view('attorney.initials.initial-application-form');
    }
}
