<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyContractController extends Controller
{
    public function contract()
    {
        return view('attorney.contract');
    }
}
