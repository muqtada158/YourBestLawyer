<?php

namespace App\Http\Controllers\Attorney;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttorneyApplicationController extends Controller
{
    public function application()
    {
        return view('attorney.applications');
    }
    public function add_application()
    {
        return view('attorney.applications-add');
    }
    public function application_initial_process()
    {
        return view('attorney.application-initial-process');
    }
}
