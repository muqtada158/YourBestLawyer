<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminPaymentTransactionController extends Controller
{
    public function payment_transactions()
    {
        return view('admin.payment-transactions');
    }
}
