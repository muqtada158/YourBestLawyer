<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminMediaController extends Controller
{
    public function media()
    {
        return view('admin.media');
    }
}
