<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminApplicationController extends Controller
{
    public function application()
    {
        return view('admin.applications');
    }
    public function application_attornies()
    {
        return view('admin.application-attornies');
    }
    public function application_customers()
    {
        return view('admin.application-customers');
    }
    public function application_details()
    {
        return view('admin.application-details');
    }
    public function application_attorney_details()
    {
        return view('admin.application-attornies-detail');
    }
}
