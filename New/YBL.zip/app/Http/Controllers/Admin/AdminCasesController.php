<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminCasesController extends Controller
{
    public function cases()
    {
        return view('admin.cases');
    }
    public function all_cases()
    {
        return view('admin.cases-all');
    }
    public function ongoing_cases()
    {
        return view('admin.cases-ongoing');
    }
    public function case_details()
    {
        return view('admin.case-details');
    }
}
