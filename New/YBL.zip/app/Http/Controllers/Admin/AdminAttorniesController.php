<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminAttorniesController extends Controller
{
    public function attornies()
    {
        return view('admin.attornies');
    }
    public function attornies_details()
    {
        return view('admin.attornies-details');
    }
}
