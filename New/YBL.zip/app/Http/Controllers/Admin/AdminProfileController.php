<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminProfileController extends Controller
{
    public function profile()
    {
        return view('admin.my-profile');
    }
    public function profile_edit()
    {
        return view('admin.my-profile-edit');
    }
}
