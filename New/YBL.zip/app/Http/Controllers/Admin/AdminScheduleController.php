<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminScheduleController extends Controller
{
    public function schedule()
    {
        return view('admin.schedule');
    }
}
