<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminClientController extends Controller
{
    public function clients()
    {
        return view('admin.clients');
    }
}
