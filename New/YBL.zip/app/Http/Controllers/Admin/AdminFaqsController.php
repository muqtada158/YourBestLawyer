<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminFaqsController extends Controller
{
    public function faqs()
    {
        return view('admin.faqs');
    }
}
