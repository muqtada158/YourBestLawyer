<?php

namespace App\Http\Controllers\Apis\Attorney;

use App\Http\Controllers\Controller;
use App\Models\CustomerContract;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContractApiController extends Controller
{
    public function getNewContracts(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $contracts = CustomerContract::with('getCustomer.getUserDetails','getCaseDetail','getContract')
            ->where('attorney_id',$request->attorney_id)
            ->where('status','Pending')
            ->orderby('id','DESC')
            ->get();

            return response()->json([
                'status' => true,
                'message' => 'Customer contracts fetched successfully.',
                'contracts' => $contracts
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getAcceptedConracts(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $contracts = CustomerContract::with('getCustomer.getUserDetails','getCaseDetail','getContract')
            ->where('attorney_id',$request->attorney_id)
            ->where('status','Accepted')
            ->orderby('id','DESC')
            ->get();

            return response()->json([
                'status' => true,
                'message' => 'Customer contracts fetched successfully.',
                'contracts' => $contracts
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getContractDetails(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'contract_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $contract = CustomerContract::with('getCustomer.getUserDetails','getCaseDetail','getContract')
            ->where('id',$request->contract_id)
            ->first();

            return response()->json([
                'status' => true,
                'message' => 'Customer contract details fetched successfully.',
                'contract' => $contract
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function acceptContract(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'contract_id' => 'required',
                'attorney_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $contract = CustomerContract::where('id',$request->contract_id)
            ->where('attorney_id',$request->attorney_id)->first();

            $contract->status = 'Accepted';
            $contract->save();

            $getUser = User::where('id',$contract->customer_id)->first();
            if($getUser->restricted_steps == 16)
            {
                $updateUserRestrictedStep = User::where('id',$contract->customer_id)->update(['restricted_steps'=> 17]);
            }

            return response()->json([
                'status' => true,
                'message' => 'Contract agreed successfully.',
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
