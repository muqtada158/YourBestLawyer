<?php

namespace App\Http\Controllers\Apis\Attorney;

use App\Http\Controllers\Controller;
use App\Models\CaseAttornies;
use App\Models\CaseDetail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CaseFeedApiController extends Controller
{
    public function caseFeed(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //get attorney
            $attorney = User::with('getAttorneyType')->where('id',$request->attorney_id)->first();

            // Collect all law_cat_id and lawyer_id values from the attorney types
            $lawCatIds = collect();
            $lawyerIds = collect();

            if ($attorney->getAttorneyType) {
                //string law_cat_ids and lawyer_ids to its collection variable
                $lawCatIds = $lawCatIds->merge($attorney->getAttorneyType->pluck('law_cat_id'));
                $lawyerIds = $lawyerIds->merge($attorney->getAttorneyType->pluck('lawyer_id'));
            }

            // Removing duplicates
            $lawCatIds = $lawCatIds->unique();
            $lawyerIds = $lawyerIds->unique();

            // Get customer contracts according to attorney types
            $cases = CaseDetail::with('getCaseMedia','getCaseBid','getUser.getUserDetails')
                ->where('application_status', 'Accepted')
                ->where('case_status', 'Pending')
                ->whereIn('case_type', $lawCatIds)
                ->whereIn('package_type', $lawyerIds)
                ->orderby('id','DESC')
                ->get();

            //rejecting case_detail data on NotInterested status
            $caseAttornies = CaseAttornies::where('attorney_id',$request->attorney_id)->first();
            if (isset($caseAttornies) && $caseAttornies->status == "NotInterested") {
                $caseIdToReject = $caseAttornies->case_id;
                $cases = $cases->reject(function ($case) use ($caseIdToReject) {
                    return $case->id == $caseIdToReject;
                });

                //converting data after rejecting
                $cases = $cases->values()->toArray();
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched data successfully',
                'cases' => $cases,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseFeedDetails(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            // Get customer contracts according to attorney types
            $cases = CaseDetail::with('getCaseMedia','getCaseBid','getUser.getUserDetails')
                ->where('id',$request->case_id)
                ->where('case_status', 'Pending')
                ->first();

            return response()->json([
                'status' => true,
                'message' => 'Fetched data successfully',
                'cases' => $cases,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseAttornies(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required|exists:case_details,id',
                'attorney_id' => 'required|exists:users,id',
                'attorney_bid' => 'nullable',
                'status' => 'required|in:Interested,NotInterested',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $caseInterestedAttornies = new CaseAttornies();
            $caseInterestedAttornies->case_id = $request->case_id;
            $caseInterestedAttornies->attorney_id = $request->attorney_id;
            $caseInterestedAttornies->attorney_bid = $request->attorney_bid;
            $caseInterestedAttornies->status = $request->status;
            $caseInterestedAttornies->save();

            return response()->json([
                'status' => true,
                'message' => 'Submit data successfully',
                'caseInterestedAttornies' => $caseInterestedAttornies,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

}
