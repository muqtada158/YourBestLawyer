<?php

namespace App\Http\Controllers\Apis\Attorney;

use App\Http\Controllers\Controller;
use App\Models\CaseAttornies;
use App\Models\CaseDetail;
use App\Models\CustomerContract;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AttorneyCasesApisController extends Controller
{
    public function getCasesCounts(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $casesTotal = CustomerContract::where('attorney_id',$request->attorney_id)
            ->get()
            ->count();

            $casesOngoing = CustomerContract::where('attorney_id',$request->attorney_id)
            ->where('status','Accepted')
            ->get()
            ->count();

            $casesPending = CustomerContract::where('attorney_id',$request->attorney_id)
            ->where('status','Pending')
            ->get()
            ->count();

            $casesEnded = CustomerContract::where('attorney_id',$request->attorney_id)
            ->where('status','Ended')
            ->get()
            ->count();

            return response()->json([
                'status' => true,
                'message' => 'Fetched cases counts successfully',
                'casesTotal' => $casesTotal,
                'casesOngoing' => $casesOngoing,
                'casesPending' => $casesPending,
                'casesEnded' => $casesEnded,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }

    }

    public function listCases(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
                'filter' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            switch ($request->filter) {
                case 'total':
                    $cases = CustomerContract::with('getAttornies.getUserDetails','getCustomer.getUserDetails','getCaseDetail.getCaseMedia','getContract')
                    ->where('attorney_id',$request->attorney_id)
                    ->orderby('id','DESC')
                    ->get();
                    break;
                case 'ongoing':
                    $cases = CustomerContract::with('getAttornies.getUserDetails','getCustomer.getUserDetails','getCaseDetail.getCaseMedia','getContract')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('status','Accepted')
                    ->orderby('id','DESC')
                    ->get();
                    break;
                case 'pending':
                    $cases = CustomerContract::with('getAttornies.getUserDetails','getCustomer.getUserDetails','getCaseDetail.getCaseMedia','getContract')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('status','Pending')
                    ->orderby('id','DESC')
                    ->get();
                    break;
                case 'ended':
                    $cases = CustomerContract::with('getAttornies.getUserDetails','getCustomer.getUserDetails','getCaseDetail.getCaseMedia','getContract')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('status','Ended')
                    ->orderby('id','DESC')
                    ->get();
                    break;
                default:
                    return response()->json([
                        'status' => false,
                        'message' => 'Error ! Invalid filter used...'
                    ], 500);
                    break;
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched cases list successfully',
                'cases' => $cases,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function detailCases(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
                'attorney_id' => 'required',
                'filter' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }


            switch ($request->filter) {
                case 'pending':

                    $cases = CustomerContract::with('getCaseDetail.getCaseMedia')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('case_id',$request->case_id)
                    ->where('status','Pending')
                    ->first();

                    break;
                case 'ongoing':

                    $cases = CustomerContract::with('getCaseDetail.getCaseMedia','getCaseDetail.getCaseBid')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('case_id',$request->case_id)
                    ->where('status','Accepted')
                    ->first();

                    $getAttorneyBid = CaseAttornies::where('case_id',$request->case_id)
                    ->where('attorney_id',$request->attorney_id)
                    ->first();
                    $cases->getAttorneyBid = $getAttorneyBid;

                    break;
                case 'ended':

                    $cases = CustomerContract::with('getCaseDetail.getCaseMedia')
                    ->where('attorney_id',$request->attorney_id)
                    ->where('case_id',$request->case_id)
                    ->where('status','Ended')
                    ->first();

                    break;

                default:

                    return response()->json([
                        'status' => false,
                        'message' => 'Error ! Invalid filter...'
                    ], 500);

                    break;
            }


            return response()->json([
                'status' => true,
                'message' => 'Fetched cases details successfully',
                'cases' => $cases,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }


}
