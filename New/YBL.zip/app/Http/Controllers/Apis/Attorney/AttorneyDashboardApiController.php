<?php

namespace App\Http\Controllers\Apis\Attorney;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\CaseDetail;
use App\Models\Faq;
use App\Models\LawCategory;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AttorneyDashboardApiController extends Controller
{
    public function search(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'search' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $searchTerm = $request->input('search');

            // First, search in CaseDetail model by sr_no
            $caseResults = CaseDetail::where('sr_no', 'like', '%' . $searchTerm . '%')->get();
            if ($caseResults->isNotEmpty()) {
                $caseImage = asset('images/search_image/searchImage.png');
                foreach ($caseResults as $case) {
                    $case->image = $caseImage;
                }
            }

            // If no results found in CaseDetail, search in LawCategory model by title
            if ($caseResults->isEmpty()) {
                $lawCategoryResults = LawCategory::with('subCategories')->where('title', 'like', '%' . $searchTerm . '%')->get();

                if ($lawCategoryResults->isEmpty()) {
                    return response()->json([
                        'status' => true,
                        'message' => 'No results found.',
                        'search' => []
                    ], 200);
                }

                return response()->json([
                    'status' => true,
                    'message' => 'Searched successfully.',
                    'search' => $lawCategoryResults
                ], 200);
            }

            return response()->json([
                'status' => true,
                'message' => 'Searched successfully.',
                'search' => $caseResults
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }



    public function faqs()
    {
        try {
            //fetch faq data
            $faqs = Faq::where('faq_status','Enabled')->get();

            return response()->json([
                'status' => true,
                'message' => 'Faqs fetched successfully',
                'data'  => $faqs
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getAllCustomerAppointments(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $appointments = Appointment::where('attorney_id',$request->attorney_id)
            ->orderby('id','Desc')->get();

            return response()->json([
                'status' => true,
                'message' => 'Fetched all appointments successfully',
                'appointment' => $appointments,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }

    }

    public function getCustomerAppointments(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'customer_id' => 'required',
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $appointments = Appointment::where('customer_id', $request->customer_id)
            ->where('attorney_id',$request->attorney_id)
            ->orderby('id','Desc')->get();

            return response()->json([
                'status' => true,
                'message' => 'Fetched appointments successfully',
                'appointment' => $appointments,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }

    }

    public function scheduleAppointment(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_sr_no' => 'required',
                'customer_id' => 'required',
                'attorney_id' => 'required',
                'date' => 'required',
                'time' => 'required',
                'case_type' => 'required',
                'summary' => 'nullable',
            ], [
                'attorney_id.required' => 'The attorney field is required.',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            if($request->case_sr_no){
                $check_sr_no = CaseDetail::where('sr_no',$request->case_sr_no)->exists();
                if(!$check_sr_no){
                    return response()->json([
                        'status' => false,
                        'message' => 'Case_sr_no did not exists, kindly enter valid case_sr_no.'
                    ], 500);
                }
            }

            $appointment = new Appointment();
            $appointment->case_sr_no = $request->case_sr_no;
            $appointment->customer_id = $request->customer_id;
            $appointment->attorney_id = $request->attorney_id;
            $appointment->date = $request->date;
            $appointment->time = $request->time;
            $appointment->case_type = $request->case_type;
            $appointment->summary = $request->summary;
            $appointment->status = 'Pending';
            $appointment->save();

            return response()->json([
                'status' => true,
                'message' => 'Schedule appointment successfully',
                'appointment' => $appointment,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
