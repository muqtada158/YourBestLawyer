<?php

namespace App\Http\Controllers\Apis\Customer;

use App\Http\Controllers\Controller;
use App\Http\Traits\NumberGeneratorTrait;
use App\Models\CaseBid;
use App\Models\CaseDetail;
use App\Models\CaseMedia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ApplicationApisController extends Controller
{
    use NumberGeneratorTrait;

    public function allApplications(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'filter' => 'nullable'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            if(isset($request->filter) && $request->filter == "Accepted")
            {
                $applications = CaseDetail::with('getCaseMedia')
                ->where('user_id', $request->user_id)
                ->where('application_status','Accepted')
                ->orderby('id','DESC')
                ->get();

                return response()->json([
                    'status' => true,
                    'message' => 'Fetched accepted applications successfully',
                    'applications' => $applications,
                ], 200);
            }

            if(isset($request->filter) && $request->filter == "Pending")
            {
                $applications = CaseDetail::with('getCaseMedia')
                ->where('user_id', $request->user_id)
                ->where('application_status','Pending')
                ->orderby('id','DESC')
                ->get();

                return response()->json([
                    'status' => true,
                    'message' => 'Fetched pending applications successfully',
                    'applications' => $applications,
                ], 200);
            }

            if(isset($request->filter) && $request->filter == "Rejected")
            {
                $applications = CaseDetail::with('getCaseMedia')
                ->where('user_id', $request->user_id)
                ->where('application_status','Rejected')
                ->orderby('id','DESC')
                ->get();

                return response()->json([
                    'status' => true,
                    'message' => 'Fetched rejected applications successfully',
                    'applications' => $applications,
                ], 200);
            }

            $applications = CaseDetail::with('getCaseMedia')
            ->where('user_id', $request->user_id)
            ->where('application_status','!=',null)
            ->get();

            if(!$applications)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'Applications not found.',
                ], 422);
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched applications successfully',
                'applications' => $applications,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }


    public function viewApplication(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $application = CaseDetail::with('getCaseMedia','getUser')->findOrFail($request->id);

            return response()->json([
                'status' => true,
                'message' => 'Application fetched successfully',
                'application'=>$application
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function addApplication(Request $request)
    {
        //using db transaction to avoid extra entry incase of error
        DB::beginTransaction();

        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'client_name' => 'required',
                'client_dob' => 'required',
                'preferred_language' => 'required',
                'court_where_the_case_is_at' => 'required',
                'case_or_citation_number' => 'nullable',
                'charges' => 'required',
                'next_court_date' => 'required',
                'type_of_hearing' => 'required',
                'how_many_hearing_have_you_had' => 'required',
                'list_all_prior_criminal_convictions' => 'required',
                'case_type' => 'required',
                'case_sub_type' => 'required',
                'package_type' => 'required',
                'application' => 'required',
                'case_code' => 'nullable',
                'is_same_person' => 'nullable',
                'convictee_name' => 'nullable',
                'convictee_dob' => 'nullable',
                'convictee_relationship' => 'nullable',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $application = new CaseDetail();
            $application->user_id = $request->user_id;

            $application->sr_no = $this->uniqueNumberGenerator();

            $application->client_name = $request->client_name;
            $application->client_dob = $request->client_dob;
            $application->preferred_language = $request->preferred_language;
            $application->court_where_the_case_is_at = $request->court_where_the_case_is_at;
            $application->case_or_citation_number = $request->case_or_citation_number;
            $application->charges = $request->charges;
            $application->next_court_date = $request->next_court_date;
            $application->type_of_hearing = $request->type_of_hearing;
            $application->how_many_hearing_have_you_had = $request->how_many_hearing_have_you_had;
            $application->list_all_prior_criminal_convictions = $request->list_all_prior_criminal_convictions;
            $application->case_type = $request->case_type;
            $application->case_sub_type = $request->case_sub_type;
            $application->package_type = $request->package_type;
            $application->application = $request->application;
            $application->application_status = 'Accepted';
            $application->case_status = 'Pending';

            $application->is_same_person = $request->is_same_person;
            $application->convictee_name = $request->convictee_name;
            $application->convictee_dob = $request->convictee_dob;
            $application->convictee_relationship = $request->convictee_relationship;

            $application->save();

            //updating case_id of casemedia
            if($request->case_code)
            {
                $case_media_update = CaseMedia::where('case_id',$request->case_code)->get();
                foreach($case_media_update as $caseMedia)
                {
                    $caseMedia->case_id = $application->id;
                    $caseMedia->save();
                }
            }

            $applications = CaseDetail::with('getCaseMedia','getCaseLaw','getCaseLawSub','getCasePackage')
            ->where('id',$application->id)->first();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Application submitted successfully',
                'application' => $applications,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function updateApplication(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
                'user_id' => 'required',
                'case_title' => 'required',
                'client_name' => 'required',
                'client_dob' => 'required',
                'preferred_language' => 'required',
                'court_where_the_case_is_at' => 'required',
                'case_or_citation_number' => 'nullable',
                'charges' => 'required',
                'next_court_date' => 'required',
                'type_of_hearing' => 'required',
                'how_many_hearing_have_you_had' => 'required',
                'list_all_prior_criminal_convictions' => 'required',
                'case_type' => 'required',
                'case_sub_type' => 'required',
                'package_type' => 'required',
                'application' => 'required',
                'case_code' => 'nullable',
                'is_same_person' => 'nullable',
                'convictee_name' => 'nullable',
                'convictee_dob' => 'nullable',
                'convictee_relationship' => 'nullable',

            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $application = CaseDetail::where('id',$request->case_id)->first();
            if(!$application){
                return response()->json([
                    'status' => false,
                    'message' => 'Application not found.',
                ], 404);
            }

            $application->user_id = $request->user_id;
            $application->case_title = $request->case_title;
            $application->client_name = $request->client_name;
            $application->client_dob = $request->client_dob;
            $application->preferred_language = $request->preferred_language;
            $application->court_where_the_case_is_at = $request->court_where_the_case_is_at;
            $application->case_or_citation_number = $request->case_or_citation_number;
            $application->charges = $request->charges;
            $application->next_court_date = $request->next_court_date;
            $application->type_of_hearing = $request->type_of_hearing;
            $application->how_many_hearing_have_you_had = $request->how_many_hearing_have_you_had;
            $application->list_all_prior_criminal_convictions = $request->list_all_prior_criminal_convictions;
            $application->case_type = $request->case_type;
            $application->case_sub_type = $request->case_sub_type;
            $application->package_type = $request->package_type;
            $application->application = $request->application;

            $application->is_same_person = $request->is_same_person;
            $application->convictee_name = $request->convictee_name;
            $application->convictee_dob = $request->convictee_dob;
            $application->convictee_relationship = $request->convictee_relationship;

            $application->save();

            //updating case_id of casemedia
            if($request->case_code)
            {
                $case_media_update = CaseMedia::where('case_id',$request->case_code)->get();
                foreach($case_media_update as $caseMedia)
                {
                    $caseMedia->case_id = $application->id;
                    $caseMedia->save();
                }
            }

            $applications = CaseDetail::with('getCaseMedia','getCaseLaw','getCaseLawSub','getCasePackage')
            ->where('id',$application->id)->first();

            return response()->json([
                'status' => true,
                'message' => 'Application updated successfully',
                'application' => $applications,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }


    public function placeBidForApplication(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'case_id' => 'required',
                'bid' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case_bid = new CaseBid();
            $case_bid->user_id = $request->user_id;
            $case_bid->case_id = $request->case_id;
            $case_bid->bid = number_format($request->bid, 2, '.', '');;
            $case_bid->save();

            return response()->json([
                'status' => true,
                'message' => 'Application bid saved successfully',
                'caseBid' => $case_bid
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }



    public function deleteApplication(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $application = CaseDetail::findOrFail($request->id);
            if($application->case_status == 'Accepted')
            {
                return response()->json([
                    'status' => true,
                    'message' => "This application's case accepted already, and cannot be deleted.",
                ], 200);
            }

            $application->delete();
            return response()->json([
                'status' => true,
                'message' => 'Application deleted successfully',
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
