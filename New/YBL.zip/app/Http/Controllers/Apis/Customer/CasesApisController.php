<?php

namespace App\Http\Controllers\Apis\Customer;

use App\Http\Controllers\Controller;
use App\Models\CaseDetail;
use App\Models\CustomerFeedback;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CasesApisController extends Controller
{
    public function allCases(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'filter' => 'nullable'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            if(isset($request->filter) && $request->filter == "Accepted")
            {
                $cases = CaseDetail::with('getCaseMedia')->where('user_id', $request->user_id)->where('case_status','Accepted')->orderby('id','ASC')->get();
                return response()->json([
                    'status' => true,
                    'message' => 'Fetched accepted cases successfully',
                    'cases' => $cases,
                ], 200);
            }

            if(isset($request->filter) && $request->filter == "Pending")
            {
                $cases = CaseDetail::with('getCaseMedia')->where('user_id', $request->user_id)->where('case_status','Pending')->orderby('id','ASC')->get();
                return response()->json([
                    'status' => true,
                    'message' => 'Fetched pending cases successfully',
                    'cases' => $cases,
                ], 200);
            }

            if(isset($request->filter) && $request->filter == "Ended")
            {
                $cases = CaseDetail::with('getCaseMedia')->where('user_id', $request->user_id)->where('case_status','Ended')->orderby('id','ASC')->get();
                return response()->json([
                    'status' => true,
                    'message' => 'Fetched rejected cases successfully',
                    'cases' => $cases,
                ], 200);
            }

            $cases = CaseDetail::with('getCaseMedia')->where('user_id', $request->user_id)->where('case_status','!=',null)->get();

            if(!$cases)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'cases not found.',
                ], 422);
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched cases successfully',
                'cases' => $cases,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function viewCase(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case = CaseDetail::with('getCaseMedia','getUser.getUserDetails')->findOrFail($request->case_id);

            return response()->json([
                'status' => true,
                'message' => 'Case fetched successfully',
                'case'=>$case
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function customerFeedback(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
                'customer_id' => 'required',
                'attorney_id' => 'required',
                'rating' => 'required|integer',
                'review' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case = CaseDetail::where('id',$request->case_id)->first();

            if(!$case)
            {
                return response()->json([
                    'status' => true,
                    'message' => 'Case not found.',
                ], 422);
            }

            $feedback = new CustomerFeedback();
            $feedback->case_id = $request->case_id;
            $feedback->customer_id = $request->customer_id;
            $feedback->attorney_id = $request->attorney_id;
            $feedback->rating = $request->rating;
            $feedback->review = $request->review;
            $feedback->save();

            $case->case_status = "Ended";
            $case->save();

            return response()->json([
                'status' => true,
                'message' => 'Your feedback submitted successfully Case ended,',
                'customer_feedback'=>$feedback,
                'case'=>$case
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function attorneyRatings(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $attorney = User::with('getUserDetails')->where('id',$request->attorney_id)->first();
            $ratings = CustomerFeedback::where('attorney_id',$request->attorney_id)->get()->pluck('rating')->toArray();

            if(!$ratings)
            {
                $ratings = [0];
            }

            $averageRating = number_format(array_sum($ratings) / count($ratings), 2);
            return response()->json([
                'status' => true,
                'message' => 'Attorney and rating fetched successfully.',
                'ratings'=>$averageRating,
                'attorney'=>$attorney
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
}
