<?php

namespace App\Http\Controllers\Apis\Customer;

use App\Http\Controllers\Controller;
use App\Models\CaseDetail;
use App\Models\CustomerContract;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class DashboardApisController extends Controller
{
    public function viewProfile(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $profile = User::with('getUserDetails')->where('id', $request->user_id)->first();

            if(!$profile)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'User profile not found.',
                ], 422);
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched profile successfully',
                'profile' => $profile,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function updatePassword(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'current_password' => 'required',
                'new_password' => 'required|string|min:8',
                'confirm_password' => 'required|string|same:new_password',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            $user = User::findOrFail($request->user_id);

            if(!$user)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'User user not found.',
                ], 422);
            }

            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'status' => false,
                    'message' => 'Current password is incorrect.',
                ], 422);
            }

            $user->password = Hash::make($request->new_password);
            $user->save();

            return response()->json([
                'status' => true,
                'message' => 'Password updated successfully.',
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getApplications(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $application = CaseDetail::with('getCaseMedia','getCaseBid')->where('user_id', $request->user_id)->where('case_status','Pending')->get();

            if(!$application)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'Application not found.',
                ], 422);
            }

            return response()->json([
                'status' => true,
                'message' => 'Fetched applications successfully',
                'applications' => $application,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getAssignedAttornies(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $attornies = CustomerContract::with('getAttornies.getUserDetails')->where('customer_id',$request->user_id)->get();

            if(!$attornies)
            {
                return response()->json([
                    'status' => false,
                    'message' => 'Attornies not found.',
                ], 422);
            }

            $attornies = $attornies->pluck('getAttornies')->filter(); // to get only attornies

            return response()->json([
                'status' => true,
                'message' => 'Fetched attornies successfully',
                'attornies' => $attornies,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

}
