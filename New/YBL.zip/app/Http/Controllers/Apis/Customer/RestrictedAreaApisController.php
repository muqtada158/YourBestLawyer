<?php

namespace App\Http\Controllers\Apis\Customer;

use App\Http\Controllers\Controller;
use App\Http\Traits\NumberGeneratorTrait;
use App\Models\Appointment;
use App\Models\CaseAttornies;
use App\Models\CaseBid;
use App\Models\CaseDetail;
use App\Models\CaseMedia;
use App\Models\Contracts;
use App\Models\CustomerContract;
use App\Models\LawCategory;
use App\Models\LawSubCategory;
use App\Models\Lawyer;
use App\Models\User;
use App\Models\UserDetail;
use App\Models\UserPaymentDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RestrictedAreaApisController extends Controller
{
    use NumberGeneratorTrait;

    public function updateProfile(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'dob' => 'required',
                'address' => 'required',
                'phone' => 'required',
                'image' => 'required|image|max:5120',
                'current_password' => 'nullable',
                'new_password' => 'required_with:old_password',
                'password_confirmation' => 'required_with:old_password|same:new_password'
            ]);


            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $user_detail = UserDetail::where('user_id',$request->user_id)->firstOrNew();
            $user_detail->user_id = $request->user_id;
            $user_detail->first_name = $request->first_name;
            $user_detail->last_name = $request->last_name;
            $user_detail->dob = $request->dob;
            $user_detail->address = $request->address;
            $user_detail->phone = $request->phone;
            if ($request->hasFile('image')) {
                    /** Upload new image */
                    $upload_location = '/storage/profile/';
                    $file = $request->image;
                    $name_gen = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;
                    /** Saving in DB */
                    $user_detail->image = $save_url;
            }
            $user_detail->save();

            $user = User::with('getUserDetails')->where('id',$request->user_id)->first();

            if($request->current_password)
            {
                if (Hash::check($request->current_password, $user->password)) {
                    $user->password = Hash::make($request->password);
                } else {
                    return response()->json([
                        'status' => false,
                        'message' => 'Your current password is invalid.',
                    ], 401);
                }
                $user->save();
            }

            if($user->restricted_steps == null)
            {
                $user->restricted_steps = 9;
                $user->save();
            }

            return response()->json([
                'status' => true,
                'message' => 'Profile updated successfully',
                'user' => $user,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getAllCategoriesWithSubCategoriesWithLawyers()
    {
        try {
            // $subCategories = LawCategory::with('subCategories.getLaywers')->orderby('id','ASC')->get();

            $subCategories = LawCategory::with(['subCategories' => function ($query) {
                $query->select('cat_id', 'id', 'title')
                    ->with(['getLaywers' => function ($query) {
                        $query->select('id', 'sub_cat_id', 'title', 'min_amount', 'max_amount');
                    }]);
            }])->select('id', 'title')
                ->orderBy('id', 'ASC')
                ->get();

            return response()->json([
                'status' => true,
                'message' => 'All categories with subcategories fetched successfully',
                'categories' => $subCategories,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseMediaUploadInitial(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'media_image.*' => 'nullable|image|max:5120',                   // Each image file can be up to 5MB
                'media_video.*' => 'nullable|mimetypes:video/mp4|max:20480',    // Each video file can be up to 20MB
                'media_document.*' => 'nullable|mimes:pdf,doc,docx|max:5120',   // Each document file can be up to 5MB
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case_code = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);

            if ($request->hasFile('media_image')) {
                foreach ($request->media_image as $key => $image) {
                    /** Upload new image */
                    $upload_location = '/storage/case_media/';
                    $file = $image;
                    $name_gen = hexdec(uniqid() . $key) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;

                    /** Saving in DB */
                    $case_media = new CaseMedia();
                    $case_media->user_id = $request->user_id;
                    $case_media->case_id = $case_code;
                    $case_media->type = 'image';
                    $case_media->media = $save_url;
                    $case_media->save();
                }
            }
            if ($request->hasFile('media_video')) {
                foreach ($request->media_video as $key => $image) {
                    /** Upload new video */
                    $upload_location = '/storage/case_media/';
                    $file = $image;
                    $name_gen = hexdec(uniqid() . $key) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;

                    /** Saving in DB */
                    $case_media = new CaseMedia();
                    $case_media->user_id = $request->user_id;
                    $case_media->case_id = $case_code;
                    $case_media->type = 'video';
                    $case_media->media = $save_url;
                    $case_media->save();
                }
            }
            if ($request->hasFile('media_document')) {
                foreach ($request->media_document as $key => $image) {
                    /** Upload new document */
                    $upload_location = '/storage/case_media/';
                    $file = $image;
                    $name_gen = hexdec(uniqid() . $key) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;

                    /** Saving in DB */
                    $case_media = new CaseMedia();
                    $case_media->user_id = $request->user_id;
                    $case_media->case_id = $case_code;
                    $case_media->type = 'document';
                    $case_media->media = $save_url;
                    $case_media->save();
                }
            }

            $case_media = CaseMedia::where('case_id', $case_code)->get();

            return response()->json([
                'status' => true,
                'message' => 'Case media uploaded successfully',
                'case_media' => $case_media,
                'case_code' => $case_code,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseDetails(Request $request)
    {
        //using db transaction to avoid extra entry incase of error
        DB::beginTransaction();

        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'client_name' => 'required',
                'client_dob' => 'required',
                'preferred_language' => 'required',
                'court_where_the_case_is_at' => 'required',
                'case_or_citation_number' => 'nullable',
                'charges' => 'required',
                'next_court_date' => 'required',
                'type_of_hearing' => 'required',
                'how_many_hearing_have_you_had' => 'required',
                'list_all_prior_criminal_convictions' => 'required',
                'case_type' => 'required',
                'case_sub_type' => 'required',
                'package_type' => 'required',
                'application' => 'required',
                'case_code' => 'nullable',
                'is_same_person' => 'nullable',
                'convictee_name' => 'nullable',
                'convictee_dob' => 'nullable',
                'convictee_relationship' => 'nullable',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case_detail = new CaseDetail();
            $case_detail->user_id = $request->user_id;

            $case_detail->sr_no = $this->uniqueNumberGenerator();

            $case_detail->client_name = $request->client_name;
            $case_detail->client_dob = $request->client_dob;
            $case_detail->preferred_language = $request->preferred_language;
            $case_detail->court_where_the_case_is_at = $request->court_where_the_case_is_at;
            $case_detail->case_or_citation_number = $request->case_or_citation_number;
            $case_detail->charges = $request->charges;
            $case_detail->next_court_date = $request->next_court_date;
            $case_detail->type_of_hearing = $request->type_of_hearing;
            $case_detail->how_many_hearing_have_you_had = $request->how_many_hearing_have_you_had;
            $case_detail->list_all_prior_criminal_convictions = $request->list_all_prior_criminal_convictions;
            $case_detail->case_type = $request->case_type;
            $case_detail->case_sub_type = $request->case_sub_type;
            $case_detail->package_type = $request->package_type;
            $case_detail->application = $request->application;
            $case_detail->application_status = null;
            $case_detail->case_status = null;

            $case_detail->is_same_person = $request->is_same_person;
            $case_detail->convictee_name = $request->convictee_name;
            $case_detail->convictee_dob = $request->convictee_dob;
            $case_detail->convictee_relationship = $request->convictee_relationship;

            $case_detail->save();

            //updating case_id of casemedia
            if($request->case_code)
            {
                $case_media_update = CaseMedia::where('case_id',$request->case_code)->get();
                foreach($case_media_update as $caseMedia)
                {
                    $caseMedia->case_id = $case_detail->id;
                    $caseMedia->save();
                }
            }

            $case_details = CaseDetail::with('getCaseMedia','getCaseLaw','getCaseLawSub','getCasePackage')
            ->where('id',$case_detail->id)->first();

            //getting contract details
            //for now it is dummy we need to send specific contracts via filter when all contracts upload to db in future
            if ($case_details) {
                $contract_detail = Contracts::latest()->first();
                // Add the contract detail to the case details object
                $case_details->contract_detail = $contract_detail;
            }

            //updating restricted_step flag for mobile app
            $user = User::where('id',$request->user_id)->first();
            if($user->restricted_steps == 9)
            {
                $user->restricted_steps = 10;
                $user->save();
            }

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Case details submitted successfully',
                'case_detail' => $case_details,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseDetailsEdit(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required',
                'user_id' => 'required',
                'client_name' => 'required',
                'client_dob' => 'required',
                'preferred_language' => 'required',
                'court_where_the_case_is_at' => 'required',
                'case_or_citation_number' => 'nullable',
                'charges' => 'required',
                'next_court_date' => 'required',
                'type_of_hearing' => 'required',
                'how_many_hearing_have_you_had' => 'required',
                'list_all_prior_criminal_convictions' => 'required',
                'case_type' => 'required',
                'case_sub_type' => 'required',
                'package_type' => 'required',
                'application' => 'required',
                'case_code' => 'nullable',
                'is_same_person' => 'nullable',
                'convictee_name' => 'nullable',
                'convictee_dob' => 'nullable',
                'convictee_relationship' => 'nullable',

            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $case_detail = CaseDetail::where('id',$request->case_id)->first();
            $case_detail->user_id = $request->user_id;
            $case_detail->client_name = $request->client_name;
            $case_detail->client_dob = $request->client_dob;
            $case_detail->preferred_language = $request->preferred_language;
            $case_detail->court_where_the_case_is_at = $request->court_where_the_case_is_at;
            $case_detail->case_or_citation_number = $request->case_or_citation_number;
            $case_detail->charges = $request->charges;
            $case_detail->next_court_date = $request->next_court_date;
            $case_detail->type_of_hearing = $request->type_of_hearing;
            $case_detail->how_many_hearing_have_you_had = $request->how_many_hearing_have_you_had;
            $case_detail->list_all_prior_criminal_convictions = $request->list_all_prior_criminal_convictions;
            $case_detail->case_type = $request->case_type;
            $case_detail->case_sub_type = $request->case_sub_type;
            $case_detail->package_type = $request->package_type;
            $case_detail->application = $request->application;

            $case_detail->is_same_person = $request->is_same_person;
            $case_detail->convictee_name = $request->convictee_name;
            $case_detail->convictee_dob = $request->convictee_dob;
            $case_detail->convictee_relationship = $request->convictee_relationship;

            $case_detail->save();


            //updating case_id of casemedia
            if($request->case_code)
            {
                $case_media_update = CaseMedia::where('case_id',$request->case_code)->get();
                foreach($case_media_update as $caseMedia)
                {
                    $caseMedia->case_id = $case_detail->id;
                    $caseMedia->save();
                }
            }

            $case_details = CaseDetail::with('getCaseMedia','getCaseLaw','getCaseLawSub','getCasePackage')
            ->where('id',$case_detail->id)->first();

            return response()->json([
                'status' => true,
                'message' => 'Case details submitted successfully',
                'case_detail' => $case_details,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseBidAndUserPaymentDetails(Request $request)
    {
        try {
            // Validated
            $validateUser = Validator::make($request->all(), [
                'user_id' => 'required',
                'case_id' => 'required',
                'bid' => 'required',
                'stripe_intent_id' => 'required',
                'stripe_customer_id' => 'required',
                'card_expiry_month' => 'nullable',
                'card_expiry_year' => 'nullable',
                'card_last_four' => 'nullable',
                'json_response' => 'nullable',
            ]);

            if ($validateUser->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            // Begin a transaction
            DB::beginTransaction();

            $case_bid = new CaseBid();
            $case_bid->user_id = $request->user_id;
            $case_bid->case_id = $request->case_id;
            $case_bid->bid = number_format($request->bid, 2, '.', '');;
            $case_bid->save();

            $user_payment_details = new UserPaymentDetails();
            $user_payment_details->user_id = $request->user_id;
            $user_payment_details->stripe_intent_id = $request->stripe_intent_id;
            $user_payment_details->stripe_customer_id = $request->stripe_customer_id;
            $user_payment_details->card_expiry_month = $request->card_expiry_month;
            $user_payment_details->card_expiry_year = $request->card_expiry_year;
            $user_payment_details->card_last_four = $request->card_last_four;
            $user_payment_details->json_response = $request->json_response;
            $user_payment_details->save();

            $user = User::where('id',$request->user_id)->first();
            if($user->restricted_steps == 10)
            {
                $user->restricted_steps = 11;
                $user->save();
            }

            // Commit the transaction
            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Case bid and payment details saved successfully',
                'case_bid' => $case_bid,
                'user_payment_details' => $user_payment_details
            ], 200);

        } catch (\Throwable $th) {
            // Rollback the transaction if an error occurs
            DB::rollBack();

            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }


    public function casePreview(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'case_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //fetch profile data
            $profile_data = User::with('getUserDetails','getUserPaymentDetails')->where('id',$request->user_id)->first();
            //fetch case data
            $case_data = CaseDetail::with('getCaseMedia','getCaseBid','getCaseLaw','getCaseLawSub','getCasePackage')->where('id',$request->case_id)->where('user_id',$profile_data->id)->first();

            return response()->json([
                'status' => true,
                'message' => 'Fetched data successfully',
                'profile_data' => $profile_data,
                'case_data' => $case_data,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function caseSubmit(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'user_id' => 'required',
                'case_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //fetch profile data
            $profile_data = User::with('getUserPaymentDetails')->where('id',$request->user_id)->first();
            //fetch case data
            $case_data = CaseDetail::where('id',$request->case_id)->update(['application_status'=>'Accepted','case_status'=>'Pending']);

            if($profile_data->restricted_steps == 11)
            {
                $profile_data->restricted_steps = 12;
                $profile_data->save();
            }

            return response()->json([
                'status' => true,
                'message' => 'Case submitted successfully'
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getAllAttornies(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //fetch attornies data
            $interstedAttornies= CaseAttornies::with('getAttornies.getUserDetails','getAttornies.getRatings','getCaseDetails.getCaseBid')
            ->where('case_id',$request->case_id)
            ->where('status','Interested')
            ->get();

            $interstedAttornies->each(function ($attorney) {
                $ratings = $attorney->getAttornies->getRatings;
                $average_rating = $ratings->avg('rating');
                $attorney->average_ratings = $average_rating;
            });

            return response()->json([
                'status' => true,
                'message' => 'Attornies fetched successfully',
                'attornies' => $interstedAttornies
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }
    public function getAttorneyDetails(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'attorney_id' => 'required',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //fetch attornies data
            $attorney_details = User::with('getUserDetails','getInterestedAttorney','getCaseCounts')->where('id',$request->attorney_id)->first();

            $ratings = $attorney_details->getRatings;
            $average_rating = $ratings->avg('rating');

            // Add the average_ratings field to the array
            $attorney_details['average_ratings'] = $average_rating;

            return response()->json([
                'status' => true,
                'message' => 'Attorney detail fetched successfully',
                'attorney_details' => $attorney_details
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function customerContract(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'customer_id' => 'required',
                'attorney_id' => 'required',
                'case_id' => 'required',
                'convictee_full_name' => 'required',
                'convictee_date' => 'required',
                'convictee_relationship' => 'required',
                'contract_date' => 'required',
                'contract_id' => 'required',
                'signature_image' => 'required|image|max:5120',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $customer_contract = new CustomerContract();
            $customer_contract->customer_id = $request->customer_id;
            $customer_contract->attorney_id = $request->attorney_id;
            $customer_contract->case_id = $request->case_id;
            $customer_contract->convictee_full_name = $request->convictee_full_name;
            $customer_contract->convictee_date = $request->convictee_date;
            $customer_contract->convictee_relationship = $request->convictee_relationship;
            $customer_contract->contract_id = $request->contract_id;
            $customer_contract->contract_date = $request->contract_date;

            if ($request->hasFile('signature_image')) {
                    /** Upload new image */
                    $upload_location = '/storage/customer-contract-signatures/';
                    $file = $request->signature_image;
                    $name_gen = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path() . $upload_location, $name_gen);
                    $save_url = $upload_location . $name_gen;

                    $customer_contract->signature_image = $save_url;
            }

            $customer_contract->save();

            $user = User::where('id',$request->customer_id)->first();

            if($user->restricted_steps == 12)
            {
                $user->restricted_steps = 16;
                $user->save();
            }

            return response()->json([
                'status' => true,
                'message' => 'Customer contract submitted successfully',
                'customer_contract' => $customer_contract,
            ], 200);

        } catch (\Throwable $th) {
            if ($th->errorInfo[1] == 1452) {
                return response()->json([
                    'status' => false,
                    'message' => 'The specified attorney or user does not exist.',
                ], 422);
            }
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function scheduleAppointment(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'case_sr_no' => 'required',
                'customer_id' => 'required',
                'attorney_id' => 'required',
                'date' => 'required',
                'time' => 'required',
                'case_type' => 'required',
                'summary' => 'nullable',
            ], [
                'attorney_id.required' => 'The attorney field is required.',
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            if($request->case_sr_no){
                $check_sr_no = CaseDetail::where('sr_no',$request->case_sr_no)->exists();
                if(!$check_sr_no){
                    return response()->json([
                        'status' => false,
                        'message' => 'Case_sr_no did not exists, kindly enter valid case_sr_no.'
                    ], 500);
                }
            }

            $appointment = new Appointment();
            $appointment->case_sr_no = $request->case_sr_no;
            $appointment->customer_id = $request->customer_id;
            $appointment->attorney_id = $request->attorney_id;
            $appointment->date = $request->date;
            $appointment->time = $request->time;
            $appointment->case_type = $request->case_type;
            $appointment->summary = $request->summary;
            $appointment->status = 'Pending';
            $appointment->save();

            $user = User::where('id',$request->customer_id)->first();

            if($user->restricted_steps == 16)
            {
                $user->restricted_steps = 19;
                $user->save();
            }

            return response()->json([
                'status' => true,
                'message' => 'Schedule appointment successfully',
                'appointment' => $appointment,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function getUsersAppointments(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'customer_id' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            $appointments = Appointment::where('customer_id', $request->customer_id)->where('status','Approved')->get();

            return response()->json([
                'status' => true,
                'message' => 'Fetched appointments successfully',
                'appointment' => $appointments,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }

    }

    public function getContractDetails(Request $request)
    {
        try {
            //Validated
            $validateUser = Validator::make($request->all(),
            [
                'law_cat_id' => 'nullable',
                'package_id' => 'nullable'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }

            //in future need to authenticate the query with law_cat_id and package_id

            //for now its dummy
            $contract = Contracts::where('id',1)->first();

            return response()->json([
                'status' => true,
                'message' => 'Fetched Contract successfully',
                'contract' => $contract,
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }

    }




}
