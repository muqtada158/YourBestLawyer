<?php

namespace App\Http\Traits;

use App\Models\CaseDetail;

trait NumberGeneratorTrait
{
    public function uniqueNumberGenerator()
    {
        do {
            $uniqueNumber = rand(10000, 99999);
        } while (CaseDetail::where('sr_no', $uniqueNumber)->exists());

        return $uniqueNumber;
    }
}
