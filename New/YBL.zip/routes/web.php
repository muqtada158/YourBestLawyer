<?php

use App\Http\Controllers\Admin\AdminApplicationController;
use App\Http\Controllers\Admin\AdminAttorniesController;
use App\Http\Controllers\Admin\AdminCasesController;
use App\Http\Controllers\Admin\AdminClientController;
use App\Http\Controllers\Admin\AdminContractController;
use App\Http\Controllers\Admin\AdminFaqsController;
use App\Http\Controllers\Admin\AdminInviteController;
use App\Http\Controllers\Admin\AdminMediaController;
use App\Http\Controllers\Admin\AdminPaymentTransactionController;
use App\Http\Controllers\Admin\AdminProfileController;
use App\Http\Controllers\Admin\AdminScheduleController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Attorney\AttorneyApplicationController;
use App\Http\Controllers\Attorney\AttorneyCasesController;
use App\Http\Controllers\Attorney\AttorneyChatController;
use App\Http\Controllers\Attorney\AttorneyContractController;
use App\Http\Controllers\Attorney\AttorneyFaqsController;
use App\Http\Controllers\Attorney\AttorneyInitials;
use App\Http\Controllers\Attorney\AttorneyInviteController;
use App\Http\Controllers\Attorney\AttorneyLeadsController;
use App\Http\Controllers\Attorney\AttorneyMediaController;
use App\Http\Controllers\Attorney\AttorneyPaymentTransactionController;
use App\Http\Controllers\Attorney\AttorneyProfileController;
use App\Http\Controllers\Attorney\AttorneyScheduleController;
use App\Http\Controllers\Customer\DashboardController as CustomerDashboardController;
use App\Http\Controllers\Attorney\DashboardController as AttorneyDashboardController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Customer\CustomerApplicationController;
use App\Http\Controllers\Customer\CustomerAttorniesController;
use App\Http\Controllers\Customer\CustomerCasesController;
use App\Http\Controllers\Customer\CustomerChatController;
use App\Http\Controllers\Customer\CustomerContractController;
use App\Http\Controllers\Customer\CustomerInitials;
use App\Http\Controllers\Customer\CustomerInviteController;
use App\Http\Controllers\Customer\CustomerMediaController;
use App\Http\Controllers\Customer\CustomerPaymentTransactionController;
use App\Http\Controllers\Customer\CustomerProfileController;
use App\Http\Controllers\Customer\CustomerScheduleController;
use App\Http\Controllers\Customer\CustomerVideoController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Auth::routes();

//front website un-authenticated user routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('lawyers', [HomeController::class, 'lawyers'])->name('lawyers');
Route::get('customers', [HomeController::class, 'customers'])->name('customers');


// authentication routes
Route::get('auth', [LoginController::class, 'index'])->name('auth_index');
Route::get('auth/login', [LoginController::class, 'login_view'])->name('login_view');
Route::get('auth/register', [RegisterController::class, 'register_view'])->name('register_view');
Route::get('auth/verify-email', [RegisterController::class, 'verify_email'])->name('verify_email');
Route::post('auth/verify-email-post', [RegisterController::class, 'verifyEmail'])->name('verifyEmail');
Route::post('auth/resend-code', [RegisterController::class, 'resendCode'])->name('resendCode');
Route::get('auth/verification', [RegisterController::class, 'verification'])->name('verification');
Route::get('auth/password-reset', [ForgotPasswordController::class, 'reset_view'])->name('reset_view');




// middleware routes
Route::middleware('admin')->prefix('admin')->group(function () {

    //dashboard
    Route::get('dashboard', [AdminDashboardController::class, 'dashboard'])->name('admin_dashboard');

    //attornies
    Route::get('attornies', [AdminAttorniesController::class, 'attornies'])->name('admin_attornies');
    Route::get('attornies-details', [AdminAttorniesController::class, 'attornies_details'])->name('admin_attornies_details');

    //clients
    Route::get('clients', [AdminClientController::class, 'clients'])->name('admin_clients');

    //applications
    Route::get('application', [AdminApplicationController::class, 'application'])->name('admin_application');
    Route::get('application-attornies', [AdminApplicationController::class, 'application_attornies'])->name('admin_application_attornies');
    Route::get('application-customers', [AdminApplicationController::class, 'application_customers'])->name('admin_application_customers');
    Route::get('application-details', [AdminApplicationController::class, 'application_details'])->name('admin_application_details');
    Route::get('application-attorney-details', [AdminApplicationController::class, 'application_attorney_details'])->name('admin_application_attorney_details');

    //cases
    Route::get('cases', [AdminCasesController::class, 'cases'])->name('admin_cases');
    Route::get('all-cases', [AdminCasesController::class, 'all_cases'])->name('admin_all_cases');
    Route::get('ongoing-cases', [AdminCasesController::class, 'ongoing_cases'])->name('admin_ongoing_cases');
    Route::get('cases-details', [AdminCasesController::class, 'case_details'])->name('admin_case_details');

    //media
    Route::get('media', [AdminMediaController::class, 'media'])->name('admin_media');

    //faqs
    Route::get('faqs', [AdminFaqsController::class, 'faqs'])->name('admin_faqs');

    //payment transactions
    Route::get('payment-transcations', [AdminPaymentTransactionController::class, 'payment_transactions'])->name('admin_payment_transactions');

    //schedule
    Route::get('schedule', [AdminScheduleController::class, 'schedule'])->name('admin_schedule');

    //invite
    Route::get('invite', [AdminInviteController::class, 'invite'])->name('admin_invite');

    //contract
    Route::get('contract', [AdminContractController::class, 'contract'])->name('admin_contract');

    //profile
    Route::get('profile', [AdminProfileController::class, 'profile'])->name('admin_profile');
    Route::get('edit-profile', [AdminProfileController::class, 'profile_edit'])->name('admin_profile_edit');

});

Route::middleware('customer')->prefix('customer')->group(function () {

    //for first interaction area starts
    Route::get('update-profile', [CustomerInitials::class, 'update_profile'])->name('customer_update_profile');
    Route::post('update-profile', [CustomerInitials::class, 'updateProfile'])->name('customer_update_profile_form');

    Route::get('application-steps', [CustomerInitials::class, 'application_steps'])->name('customer_application_steps');
    Route::get('initial-hired-attornies', [CustomerInitials::class, 'hired_attornies'])->name('customer_hired_attornies');
    Route::get('initial-attornies-details', [CustomerInitials::class, 'hired_attornies_details'])->name('customer_hired_attornies_details');
    Route::get('initial-contract', [CustomerInitials::class, 'contracts'])->name('customer_contracts');
    Route::get('checkout', [CustomerInitials::class, 'checkout'])->name('customer_checkout');
    Route::get('initial-schedule', [CustomerInitials::class, 'schedule'])->name('customer_initial_schedule');
    Route::get('initial-schedule-appointment', [CustomerInitials::class, 'schedule_appointment'])->name('customer_initial_schedule_appointment');
    //for first interaction area ends

    //dashboard
    Route::get('dashboard', [CustomerDashboardController::class, 'dashboard'])->name('customer_dashboard');

    //applications
    Route::get('applications', [CustomerApplicationController::class, 'applications'])->name('customer_applications');
    Route::get('add-application', [CustomerApplicationController::class, 'add_application'])->name('customer_add_application');
    Route::get('application-initial-process', [CustomerApplicationController::class, 'application_initial_process'])->name('application_initial_process');

    //cases
    Route::get('cases', [CustomerCasesController::class, 'cases'])->name('customer_cases');
    Route::get('all-cases', [CustomerCasesController::class, 'all_cases'])->name('customer_all_cases');
    Route::get('current-potential-cases', [CustomerCasesController::class, 'current_potential_cases'])->name('customer_current_potential_cases');
    Route::get('cases-details', [CustomerCasesController::class, 'case_details'])->name('customer_case_details');

    //attornies
    Route::get('attornies', [CustomerAttorniesController::class, 'attornies'])->name('customer_attornies');
    Route::get('attornies-detail', [CustomerAttorniesController::class, 'attornies_details'])->name('customer_attornies_details');

    //messages
    Route::get('messages', [CustomerChatController::class, 'messages'])->name('customer_messages');

    //media
    Route::get('media', [CustomerMediaController::class, 'media'])->name('customer_media');

    //videos
    Route::get('videos', [CustomerVideoController::class, 'videos'])->name('customer_videos');
    Route::get('video-details', [CustomerVideoController::class, 'video_details'])->name('customer_video_details');

    //payment transactions
    Route::get('payment-transactions', [CustomerPaymentTransactionController::class, 'payment_transactions'])->name('customer_payment_transactions');
    Route::get('payment-transactions-add', [CustomerPaymentTransactionController::class, 'payment_transactions_add'])->name('customer_payment_transactions_add');

    //schedule
    Route::get('schedule', [CustomerScheduleController::class, 'schedule'])->name('customer_schedule');
    Route::get('schedule-appointment', [CustomerScheduleController::class, 'schedule_appointment'])->name('customer_schedule_appointment');

    //invite
    Route::get('invite', [CustomerInviteController::class, 'invite'])->name('customer_invite');
    Route::get('invite-received', [CustomerInviteController::class, 'invite_received'])->name('customer_invite_received');
    Route::get('invite-sent', [CustomerInviteController::class, 'invite_sent'])->name('customer_invite_sent');
    Route::get('invite-send', [CustomerInviteController::class, 'invite_send'])->name('customer_invite_send');

    //contract
    Route::get('contract', [CustomerContractController::class, 'contract'])->name('customer_contract');

    //profle
    Route::get('profile', [CustomerProfileController::class, 'profile'])->name('customer_profile');
    Route::get('edit-profile', [CustomerProfileController::class, 'profile_edit'])->name('customer_profile_edit');

});

Route::middleware('attorney')->prefix('attorney')->group(function () {

    //for first interaction area starts
    Route::get('update-profile', [AttorneyInitials::class, 'update_profile'])->name('attorney_update_profile');
    Route::get('initial-application-form', [AttorneyInitials::class, 'initial_application_form'])->name('attorney_initial_application_form');
    //for first interaction area ends

    //dashboard
    Route::get('dashboard', [AttorneyDashboardController::class, 'dashboard'])->name('attorney_dashboard');

    //applications
    Route::get('applications', [AttorneyApplicationController::class, 'application'])->name('attorney_applications');
    Route::get('add-application', [AttorneyApplicationController::class, 'add_application'])->name('attorney_add_application');
    Route::get('application-initial-process', [AttorneyApplicationController::class, 'application_initial_process'])->name('attorney_application_initial_process');

    //leads
    Route::get('leads', [AttorneyLeadsController::class, 'leads'])->name('attorney_leads');
    Route::get('leads-customer-details', [AttorneyLeadsController::class, 'leads_customer_details'])->name('attorney_leads_customer_details');

    //messages
    Route::get('messages', [AttorneyChatController::class, 'messages'])->name('attorney_messages');

    //cases
    Route::get('cases', [AttorneyCasesController::class, 'cases'])->name('attorney_cases');
    Route::get('all-cases', [AttorneyCasesController::class, 'all_cases'])->name('attorney_all_cases');
    Route::get('ongoing-cases', [AttorneyCasesController::class, 'ongoing_cases'])->name('attorney_ongoing_cases');
    Route::get('cases-details', [AttorneyCasesController::class, 'case_details'])->name('attorney_case_details');

    //media
    Route::get('media', [AttorneyMediaController::class, 'media'])->name('attorney_media');

    //faqs
    Route::get('faqs', [AttorneyFaqsController::class, 'faqs'])->name('attorney_faqs');

    //payment transactions
    Route::get('payment-transactions', [AttorneyPaymentTransactionController::class, 'payment_transactions'])->name('attorney_payment_transactions');
    Route::get('payment-transactions-add', [AttorneyPaymentTransactionController::class, 'payment_transactions_add'])->name('attorney_payment_transactions_add');

    //schedule
    Route::get('schedule', [AttorneyScheduleController::class, 'schedule'])->name('attorney_schedule');
    Route::get('schedule-appointment', [AttorneyScheduleController::class, 'schedule_appointment'])->name('attorney_schedule_appointment');

    //invite
    Route::get('invite', [AttorneyInviteController::class, 'invite'])->name('attorney_invite');
    Route::get('invite-received', [AttorneyInviteController::class, 'invite_received'])->name('attorney_invite_received');
    Route::get('invite-sent', [AttorneyInviteController::class, 'invite_sent'])->name('attorney_invite_sent');
    Route::get('invite-send', [AttorneyInviteController::class, 'invite_send'])->name('attorney_invite_send');

    //contract
    Route::get('contract', [AttorneyContractController::class, 'contract'])->name('attorney_contract');

    //profle
    Route::get('profile', [AttorneyProfileController::class, 'profile'])->name('attorney_profile');
    Route::get('edit-profile', [AttorneyProfileController::class, 'profile_edit'])->name('attorney_profile_edit');

});
